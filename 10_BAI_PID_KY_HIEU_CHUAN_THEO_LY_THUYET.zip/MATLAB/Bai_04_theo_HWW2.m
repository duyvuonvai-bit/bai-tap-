%% BAI 4 – GIAI CHI TIET TUNG PHUONG PHAP PI/PID THEO HW_W2
clear; clc; close all;
K = 2.4; tau = 320; theta = 48;
s = tf('s'); r = theta/tau; A = tau/(abs(K)*theta);
sg = sign(K);
%% Tu thu: ZN-PI, ZN-PID, Haalman-PI, CHR-PI, CHR-PID, CC-PI, CC-PID
names = {'ZN-PI','ZN-PID','Haalman-PI','CHR-PI','CHR-PID','CC-PI','CC-PID'};
Kp = sg*[0.9*A,1.2*A,2*A/3,0.35*A,0.6*A,...
         A*(0.9+r/12), A*(4/3+r/4)];
Ti = [3.33*theta,2*theta,tau,1.2*tau,tau,...
      theta*(30+3*r)/(9+20*r), theta*(32+6*r)/(13+8*r)];
Td = [0,theta/2,0,0,theta/2,0,4*theta/(11+2*r)];
% Haalman PID khong co quy tac rieng trong tai lieu. KHONG tu dong gan Td=0 thanh PID Haalman.
G0=K/(tau*s+1);
[numD,denD]=pade(theta,6); D=tf(numD,denD);G=G0*D;
tEnd=max(12*tau,100*theta);
t=linspace(0,tEnd,20000)';
w=logspace(log10(1e-6/theta),log10(1e3/theta),50000);
phi=linspace(0,2*pi,1500);
results=table();
figure('Color','w','Name','Dap ung step tat ca bo dieu khien');hold on;grid on;
for k=1:numel(names)
  C=Kp(k)*(1+1/(Ti(k)*s)+Td(k)*s);
  L0=minreal(C*G);
  Tc=minreal(feedback(L0,1));
  S=minreal(feedback(1,L0));
  polesCL=pole(Tc); stable=all(real(polesCL)<0);
  [y,tt]=step(Tc,t);y=squeeze(y);
  e=1-y;
  info=stepinfo(y,tt,1,'RiseTimeLimits',[.1 .9],...
                 'SettlingTimeThreshold',.02);
  Mp=max(0,(max(y)-1)*100);
  ess=e(end);IAE=trapz(tt,abs(e));ISE=trapz(tt,e.^2);ITAE=trapz(tt,tt.*abs(e));
  magS=squeeze(abs(freqresp(S,w)));
  magT=squeeze(abs(freqresp(Tc,w)));
  [Ms,iMs]=max(magS);[Mt,iMt]=max(magT);
  wMs=w(iMs);wMt=w(iMt);lambda=1/Ms;
  [GM,PM,wPi,wC]=margin(L0);
  if isinf(GM);GMdB=Inf;else; GMdB=20*log10(GM);end
  Cs=-1;Rs=1/Ms;
  if abs(Mt-1)<1e-4
     Ct=NaN;Rt=Inf;
  else
     Ct=Mt^2/(1-Mt^2);Rt=Mt/abs(1-Mt^2);
  end
  fprintf('\n====== BAI 4: %s ======\n',names{k});
  fprintf('Kp=%.6f Ti=%.6f Td=%.6f; On dinh=%d\n',Kp(k),Ti(k),Td(k),stable);
  fprintf('Mp=%.3f%% tr=%.3fs ts=%.3fs ess=%.3e\n',Mp,info.RiseTime,info.SettlingTime,ess);
  fprintf('IAE=%.3f ISE=%.3f ITAE=%.3f\n',IAE,ISE,ITAE);
  fprintf('Ms=%.4f wMs=%.6g; Mt=%.4f wMt=%.6g; lambda=%.4f\n',Ms,wMs,Mt,wMt,lambda);
  fprintf('GM=%.4f(%.3fdB) PM=%.3fdeg wPi=%.6g wC=%.6g\n',GM,GMdB,PM,wPi,wC);
  fprintf('Cs=-1 Rs=%.4f Ct=%.4g Rt=%.4g\n',Rs,Ct,Rt);
  yyDist=step(feedback(G,C),t);fprintf('Regulator: max |y_d|=%.4g y_d(end)=%.4g\n',max(abs(yyDist)),yyDist(end));
  fprintf('allmargin:');disp(allmargin(L0));
  row=table(string(names{k}),Kp(k),Ti(k),Td(k),stable,Mp,...
      info.RiseTime,info.SettlingTime,ess,IAE,ISE,ITAE,...
      Ms,Mt,lambda,wMs,wMt,GM,GMdB,PM,wPi,wC,...
      'VariableNames',{'Method','Kp','Ti','Td','Stable','Mp','tr','ts','ess','IAE','ISE','ITAE','Ms','Mt','lambda','wMs','wMt','GM','GMdB','PM','wPi','wC'});
  results=[results;row];
  plot(tt,y,'DisplayName',names{k});
  %% Nyquist, Ms/Mt, diem tan so, GM, PM
  Ljw=squeeze(freqresp(L0,w));
  fig=figure('Name',['Nyquist ',names{k}],'Color','w');hold on;grid on;
  plot(real(Ljw),imag(Ljw),'b','DisplayName','omega duong');
  plot(real(Ljw),-imag(Ljw),'b:','DisplayName','omega am');
  plot(-1,0,'rx','MarkerSize',10,'DisplayName','(-1,0)');
  plot(-1+Rs*cos(phi),Rs*sin(phi),'m--','DisplayName','Vong Ms');
  if abs(Mt-1)<1e-4
     xline(-.5,'g--','Mt=1: Re=-0.5');
  else
     plot(Ct+Rt*cos(phi),Rt*sin(phi),'g--','DisplayName','Vong Mt');
  end
  pMs=Ljw(iMs);pMt=Ljw(iMt);
  plot(real(pMs),imag(pMs),'mo','DisplayName','omega Ms');
  plot(real(pMt),imag(pMt),'gs','DisplayName','omega Mt');
  if isfinite(wPi)
      zz=squeeze(freqresp(L0,wPi));
      plot(real(zz),imag(zz),'kd','DisplayName','omega Pi / GM');
  end
  if isfinite(wC)
      zz=squeeze(freqresp(L0,wC));
      plot(real(zz),imag(zz),'k^','DisplayName','omega c / PM');
  end
  xlim([-3 2]);ylim([-3 3]);axis equal;
  xlabel('Re L0(jw)');ylabel('Im L0(jw)');title(names{k});legend('Location','best');
  figure('Name',['Bode ',names{k}],'Color','w');margin(L0);grid on;
end
figure(findobj('Type','figure','Name','Dap ung step tat ca bo dieu khien'));
yline(1,'k--');legend('Location','best');xlabel('Thoi gian (s)');ylabel('y(t)');
disp(results);
writetable(results,'Ket_qua_bai_4.csv');
