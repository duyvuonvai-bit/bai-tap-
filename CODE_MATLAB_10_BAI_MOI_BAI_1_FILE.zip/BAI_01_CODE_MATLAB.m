%% BAI 1: CODE MATLAB CHAY DOC LAP - NHAN RUN
baiCanGiai = 1;
% ================================================================
% GIAI BAI TAP CHUONG 2 - THIET KE VA CHINH DINH PI/PID
% Theo trinh tu Huong dan HW_W2: mo hinh > Pade > on dinh > step >
% IAE/ISE/ITAE > Ms/Mt > GM/PM > Bode/Nyquist > servo/regulator.
%
% MO FILE NAY TRONG MATLAB VA BAM RUN. KHONG CAN FILE .M KHAC.
% Hay GIAI NEN ZIP truoc khi mo file; khong chay truc tiep trong ZIP.
% Ket qua duoc luu vao thu muc KET_QUA_MATLAB ben canh file .m.
%
% Can Control System Toolbox, MATLAB R2018b tro len.
% Toan bo ket qua la mo phong tren mo hinh Pade bac 6.
% CHU Y: Haalman FOPDT o day CHI CO BO PI. Khong tu nhan la PID.
% CHR chon Servo 0%% overshoot (de bai khong cho ro bien the).
% ================================================================

if ~isnumeric(baiCanGiai) || any(~ismember(baiCanGiai,1:10))
    error('Sai so bai: phai la so nguyen tu 1 den 10.');
end

clc;
set(0,'DefaultFigureColor','w');
PadeBac = 6;
VeDoThi = true;
HienThiDoThi = (numel(baiCanGiai) == 1);
SoMauThoiGian = 25001;
SoMauTanSo = 16000;

% Du lieu lay tu "Bai tap chuong 2.pdf"
K_danhSach = [1.8, 0.75, 12, 2.4, 0.42, 0.065, 0.28, -1.15, 0.032, 3.2];
T_danhSach = [450, 180, 2.8, 320, 18, 35, 600, 520, 1.6, 240];
L_danhSach = [55, 25, 0.18, 48, 2.5, 4, 90, 70, 0.12, 32];
TenDoiTuong = {'Lo gia nhiet','Muc chat long','Toc do dong co', ...
    'Trao doi nhiet','Luu luong duong ong','Ap suat khi nen', ...
    'Nong do be khuay','Do am buong say','Toc do bang tai','Sao che'};
DonViVao = {'kW','L/min','V','kg/min','%','%','L/min','kW','Hz','kW'};
DonViRa = {'do C','cm','rad/s','do C','m^3/h','bar','%','%RH','m/s','do C'};

% 7 BO DIEU KHIEN KHAC NHAU (Haalman FOPDT chi xac dinh PI)
TenBoDK = {'ZN_PI','ZN_PID','Haalman_PI','CHR_PI','CHR_PID','CC_PI','CC_PID'};

ThuMucGoc = fullfile(fileparts(mfilename('fullpath')),'KET_QUA_MATLAB');
if ~exist(ThuMucGoc,'dir'), mkdir(ThuMucGoc); end
KetQuaTatCa = table();

for bai = baiCanGiai(:)'
    K = K_danhSach(bai);
    T = T_danhSach(bai);
    Ltre = L_danhSach(bai);
    ThuMucBai = fullfile(ThuMucGoc,sprintf('BAI_%02d',bai));
    if ~exist(ThuMucBai,'dir'), mkdir(ThuMucBai); end
    TepLog = fullfile(ThuMucBai,sprintf('Ket_qua_Bai_%02d.txt',bai));
    diary(TepLog); diary on;

    fprintf('\n============================================================\n');
    fprintf('BAI %d - %s\n',bai,TenDoiTuong{bai});
    fprintf('I. KHAI BAO: G(s) = K/(T*s+1)*exp(-L*s)\n');
    fprintf('K = %.8g; T = %.8g s; L = %.8g s\n',K,T,Ltre);
    fprintf('u(t): %s; y(t): %s; Don vi K: (%s)/(%s)\n',...
        DonViVao{bai},DonViRa{bai},DonViRa{bai},DonViVao{bai});
    fprintf('A = T/(abs(K)*L) = %.9g; rho = L/T = %.9g\n',...
        T/(abs(K)*Ltre), Ltre/T);
    if K < 0
        fprintf('CHU Y: K < 0. Kp phai AM de tao phan hoi am thuc su.\n');
    end

    %% 1 - Ham truyen doi tuong, Pade bac 6
    s = tf('s');
    G0 = K/(T*s+1);
    [numD,denD] = pade(Ltre,PadeBac);
    D = tf(numD,denD);
    G = minreal(G0*D);
    fprintf('\n1. DOI TUONG KHONG TRE G0(s):\n'); disp(G0);
    fprintf('XAP XI TRE PADE BAC %d, D(s):\n',PadeBac); disp(D);

    % Lua chon tuoi do mo phong theo thang thoi gian cua tung bai
    tEnd = max(35*T,100*Ltre);
    t = linspace(0,tEnd,SoMauThoiGian)';
    % Luoi logarit co thay doi theo T,L cua he nhanh/cham
    w = logspace(log10(1/(1000*T)),log10(100/Ltre),SoMauTanSo);
    wLow = logspace(log10(1/(1e5*T)),log10(1/(10*T)),2000);

    BangBai = table();
    if VeDoThi
        hTong = figure('Color','w','Visible',chonHienThi(HienThiDoThi),...
            'Name',sprintf('Bai %d - Tat ca Step',bai));
        hold on; grid on; plot(t,ones(size(t)),'k--','LineWidth',1.1,...
            'DisplayName','Gia tri dat r(t)=1');
    end

    for ib = 1:numel(TenBoDK)
        Ten = TenBoDK{ib};
        [Kp,Ti,Td] = chinhDinh(K,T,Ltre,Ten);
        fprintf('\n------------------------------------------------------------\n');
        fprintf('BO %d/%d: %s\n',ib,numel(TenBoDK),Ten);
        fprintf('Kp = %.9g; Ti = %.9g s; Td = %.9g s\n',Kp,Ti,Td);
        if Td == 0
            fprintf('C_PI(s) = %.9g * (1 + 1/(%.9g*s))\n',Kp,Ti);
        else
            fprintf('C_PID(s) = %.9g * (1 + 1/(%.9g*s) + %.9g*s)\n',Kp,Ti,Td);
        end

        % Giong Huong dan HW_W2: L0, Tcl, S
        C = Kp*(1 + 1/(Ti*s) + Td*s);
        L0 = minreal(C*G);
        Tcl = minreal(feedback(L0,1));
        S = minreal(feedback(1,L0));
        Gd2y = minreal(G*S);   % Nhieu tai d cong TRUOC doi tuong

        %% 2 - Kiem tra cuc he kin
        pCL = pole(Tcl);
        OnDinh = all(real(pCL) < -1e-10);
        fprintf('\nII. KIEM TRA CUC HE KIN\n'); disp(pCL);
        fprintf('He kin on dinh danh dinh = %d\n',OnDinh);

        %% 3 - Chi tieu mien thoi gian
        Mp = NaN; tr = NaN; ts = NaN; ess = NaN;
        IAE = NaN; ISE = NaN; ITAE = NaN;
        yMax = NaN; yCuoi = NaN; ydPeak = NaN; ydCuoi = NaN;
        if OnDinh
            [y,tt] = step(Tcl,t); y = squeeze(y); y = y(:);
            tt = tt(:); r = ones(size(tt)); e = r-y;
            info = stepinfo(y,tt,1,'RiseTimeLimits',[0.1 0.9],...
                'SettlingTimeThreshold',0.02);
            yMax = max(y); yCuoi = y(end);
            Mp = max(0,(yMax-1)*100);
            tr = info.RiseTime; ts = info.SettlingTime;
            ess = e(end);
            IAE = trapz(tt,abs(e));
            ISE = trapz(tt,e.^2);
            ITAE = trapz(tt,tt.*abs(e));
            [yd,td] = step(Gd2y,t); yd = squeeze(yd); yd = yd(:);
            td = td(:);
            ydPeak = max(abs(yd)); ydCuoi = yd(end);
            fprintf('\nIII. CHI TIEU MIEN THOI GIAN (STEP r=1)\n');
            fprintf('y_ss (so) = %.9g; y_max = %.9g\n',yCuoi,yMax);
            fprintf('Mp = %.6f %%; tr = %.6g s; ts 2%% = %.6g s\n',Mp,tr,ts);
            fprintf('ess (cuoi cua so) = %.9g; ess ly thuyet = 0 neu on dinh\n',ess);
            fprintf('IAE = %.9g; ISE = %.9g; ITAE = %.9g\n',IAE,ISE,ITAE);
            disp(info);
        else
            fprintf('He khong on dinh: bo qua chi tieu Step/tr/ts/IAE/ISE/ITAE.\n');
        end

        %% 4 - Chi tieu mien tan so
        Sw = squeeze(freqresp(S,w)); Sw = Sw(:)';
        Tw = squeeze(freqresp(Tcl,w)); Tw = Tw(:)';
        [Ms,iMs] = max(abs(Sw)); [Mt,iMt] = max(abs(Tw));
        wMs = w(iMs); wMt = w(iMt);
        lambda = 1/Ms;
        Ms_dB = 20*log10(Ms); Mt_dB = 20*log10(Mt);
        [GM,PM,wPi,wC] = margin(L0);
        if isinf(GM), GMdB=Inf; else, GMdB=20*log10(GM); end
        AM = allmargin(L0);
        Slow = squeeze(abs(freqresp(S,wLow)));
        S0 = Slow(1);
        fprintf('\nIV. CHI TIEU MIEN TAN SO / DU TRU ON DINH\n');
        fprintf('Ms = %.8f (%.5f dB), omegaMs = %.9g rad/s\n',Ms,Ms_dB,wMs);
        fprintf('Mt = %.8f (%.5f dB), omegaMt = %.9g rad/s\n',Mt,Mt_dB,wMt);
        fprintf('lambda = 1/Ms = %.8f\n',lambda);
        fprintf('GM = %.8f (= %.5f dB); PM = %.5f deg\n',GM,GMdB,PM);
        fprintf('omegaPi = %.9g rad/s; omegaC = %.9g rad/s\n',wPi,wC);
        fprintf('Bang tat ca cac du tru [allmargin]:\n'); disp(AM);

        %% 5 - Tam/ban kinh vong Ms/Mt tren mat phang L0
        Cs = -1; Rs = 1/Ms;
        MtLaDuongThang = (abs(Mt-1) <= 1e-4);
        if MtLaDuongThang
            Ct = NaN; Rt = Inf;
        else
            Ct = Mt^2/(1-Mt^2);
            Rt = Mt/abs(1-Mt^2);
        end
        fprintf('\nV. HINH HOC NYQUIST\n');
        fprintf('Vong Ms: tam (%.4f,0), ban kinh %.8f\n',Cs,Rs);
        if MtLaDuongThang
            fprintf('Mt xap xi 1: duong thang Re(L0)=-0.5 (khong phai vong tron huu han).\n');
        else
            fprintf('Vong Mt: tam (%.8g,0), ban kinh %.8g\n',Ct,Rt);
        end

        %% 6 - Servo / Regulator / Robustness theo chuong V Huong dan
        fprintf('\nVI. NHAN XET SERVO / REGULATOR / ROBUSTNESS\n');
        if OnDinh
            fprintf('Servo: ess = %.5g; Mp = %.3f%%; tr = %.4g; ts = %.4g.\n',...
                ess,Mp,tr,ts);
            fprintf('Regulator (nhieu truoc G): |yd|peak = %.7g; yd(end) = %.7g; |S(jwRatThap)|=%.5g\n',...
                ydPeak,ydCuoi,S0);
            if Ms <= 1.4, MsNhanXet = 'tot';
            elseif Ms <= 2, MsNhanXet = 'chap nhan';
            else, MsNhanXet = 'yeu'; end
            if PM>=45 && GMdB>=6 && Ms<=2
                NhanXet = 'Tuong doi ben vung theo nguong tham khao';
            else
                NhanXet = 'Can xem lai do ben vung hoac du tru on dinh';
            end
            fprintf('M_s: %s. Ket luan: %s.\n',MsNhanXet,NhanXet);
            fprintf('Muc tieu thu nghiem chinh: SERVO (dap ung buoc gia tri dat).\n');
        else
            fprintf('Khong ket luan hieu suat/ben vung khi he kin khong on dinh.\n');
        end

        %% 7 - Luu ket qua bang (1 hang cho moi bo PI/PID)
        row = table({Ten},Kp,Ti,Td,OnDinh,yCuoi,yMax,Mp,tr,ts,ess,...
            IAE,ISE,ITAE,Ms,wMs,Mt,wMt,lambda,GM,GMdB,PM,wPi,wC,...
            Cs,Rs,Ct,Rt,MtLaDuongThang,ydPeak,ydCuoi,S0,...
            'VariableNames',{'BoDieuKhien','Kp','Ti_s','Td_s','OnDinh',...
            'y_ss','y_max','Mp_pct','tr_s','ts_s','ess','IAE','ISE','ITAE',...
            'Ms','omega_Ms','Mt','omega_Mt','lambda','GM','GM_dB','PM_deg',...
            'omega_pi','omega_c','TamMs','BanKinhMs','TamMt','BanKinhMt',...
            'MtLaDuongThang','yd_Peak','yd_Cuoi','S_tanSoThap'});
        if isempty(BangBai), BangBai = row;
        else, BangBai = [BangBai; row]; end %#ok<AGROW>

        %% 8 - Ve tuong tu huong dan (Step, Bode, Nyquist, |S|/|T|)
        if VeDoThi && OnDinh
            figure(hTong); plot(tt,y,'LineWidth',1.2,'DisplayName',Ten);
            hienThi = chonHienThi(HienThiDoThi);

            h1 = figure('Color','w','Visible',hienThi,'Position',[50 50 900 650]);
            subplot(2,1,1);
            plot(tt,r,'k--',tt,y,'b','LineWidth',1.4); grid on;
            xlabel('t [s]'); ylabel('y(t)');
            title(sprintf('Bai %d %s - Step',bai,Ten));
            legend('r(t)=1','y(t)','Location','best');
            subplot(2,1,2); plot(tt,e,'r','LineWidth',1.3); grid on;
            xlabel('t [s]'); ylabel('e(t)=r(t)-y(t)'); title('Sai lech dieu khien');
            luuHinh(h1,ThuMucBai,[Ten '_01_Step_va_SaiSo.png'],HienThiDoThi);

            h2 = figure('Color','w','Visible',hienThi,'Position',[60 60 900 650]);
            margin(L0); grid on;
            title(sprintf('Bai %d %s - Bode / du tru GM PM',bai,Ten));
            luuHinh(h2,ThuMucBai,[Ten '_02_Bode_GM_PM.png'],HienThiDoThi);

            h3 = figure('Color','w','Visible',hienThi,'Position',[70 70 1100 530]);
            Ljw = squeeze(freqresp(L0,w)); Ljw=Ljw(:)';
            phi = linspace(0,2*pi,1200);
            % Bo khung toan canh + khung phong to den (-1,0)
            for iz=1:2
                subplot(1,2,iz); hold on; grid on; box on;
                plot(real(Ljw),imag(Ljw),'b','LineWidth',1.3);
                plot(real(Ljw),-imag(Ljw),'b:','LineWidth',1.0);
                plot(-1,0,'rx','MarkerSize',10,'LineWidth',2);
                plot(Cs+Rs*cos(phi),Rs*sin(phi),'m--','LineWidth',1.5);
                if MtLaDuongThang
                    plot([-0.5 -0.5],[-3 3],'g--','LineWidth',1.2);
                elseif iz==1 || Rt < 20*Rs
                    plot(Ct+Rt*cos(phi),Rt*sin(phi),'g--','LineWidth',1.2);
                end
                plot(real(Ljw(iMs)),imag(Ljw(iMs)),'mo','MarkerFaceColor','m');
                plot(real(Ljw(iMt)),imag(Ljw(iMt)),'gs','MarkerFaceColor','g');
                if isfinite(wPi) && wPi>0
                    pGM=squeeze(freqresp(L0,wPi));
                    plot(real(pGM),imag(pGM),'kd','MarkerFaceColor','y');
                    plot([-1 real(pGM)],[0 imag(pGM)],'k-.');
                end
                if isfinite(wC) && wC>0
                    pPM=squeeze(freqresp(L0,wC));
                    plot(real(pPM),imag(pPM),'k^','MarkerFaceColor','c');
                end
                axis equal;
                if iz==2
                    lim = max(2.0,3*Rs);
                    xlim([-1-lim -1+lim]); ylim([-lim lim]);
                    title('Phong to: diem toi han (-1,0)');
                else
                    title('Toan canh');
                end
                xlabel('Re L0(jw)');ylabel('Im L0(jw)');
            end
            luuHinh(h3,ThuMucBai,[Ten '_03_Nyquist_Ms_Mt.png'],HienThiDoThi);

            h4 = figure('Color','w','Visible',hienThi,'Position',[80 80 900 650]);
            subplot(2,1,1);
            semilogx(w,20*log10(max(abs(Sw),1e-12)),'m','LineWidth',1.4);
            grid on; xlabel('omega [rad/s]'); ylabel('20log10|S| [dB]');
            title(sprintf('S: Ms=%.4f, omegaMs=%.4g',Ms,wMs));
            subplot(2,1,2);
            semilogx(w,20*log10(max(abs(Tw),1e-12)),'g','LineWidth',1.4);
            grid on; xlabel('omega [rad/s]'); ylabel('20log10|T| [dB]');
            title(sprintf('T: Mt=%.4f, omegaMt=%.4g',Mt,wMt));
            luuHinh(h4,ThuMucBai,[Ten '_04_DoNhay_S_T.png'],HienThiDoThi);

            h5 = figure('Color','w','Visible',hienThi,'Position',[90 90 800 450]);
            plot(td,yd,'LineWidth',1.4); grid on;
            xlabel('t [s]'); ylabel('y_d(t)');
            title(sprintf('Bai %d %s - Nhieu buoc o dau vao G',bai,Ten));
            luuHinh(h5,ThuMucBai,[Ten '_05_Regulator_NhieuTai.png'],HienThiDoThi);
        end
    end

    if VeDoThi
        figure(hTong); yline(1,'k--');
        xlabel('t [s]');ylabel('y(t)');title(sprintf('Bai %d - so sanh PI/PID',bai));
        legend('Location','best');
        luuHinh(hTong,ThuMucBai,'00_So_Sanh_Step.png',HienThiDoThi);
    end
    fprintf('\nVII. BANG TONG HOP RIENG BAI %d\n',bai);
    disp(BangBai);
    writetable(BangBai,fullfile(ThuMucBai,sprintf('Bang_Ket_Qua_Bai_%02d.csv',bai)));
    save(fullfile(ThuMucBai,sprintf('Ket_Qua_Bai_%02d.mat',bai)),...
        'BangBai','K','T','Ltre','PadeBac');
    if isempty(KetQuaTatCa)
        BangBai.Bai = repmat(bai,height(BangBai),1);
        KetQuaTatCa = BangBai;
    else
        BangBai.Bai = repmat(bai,height(BangBai),1);
        KetQuaTatCa = [KetQuaTatCa; BangBai]; %#ok<AGROW>
    end
    diary off;
end

writetable(KetQuaTatCa,fullfile(ThuMucGoc,'Bang_Tong_Hop_Cac_Bai.csv'));
fprintf('\nHOAN THANH. Thu muc ket qua: %s\n',ThuMucGoc);
% ================= CAC HAM PHU DANG TREN CUNG FILE ===============
function [Kp,Ti,Td] = chinhDinh(K,T,Ltre,Ten)
    A = T/(K*Ltre); % Giu dau K: bai 8 co K AM thi Kp cung AM
    rho = Ltre/T;
    switch Ten
        case 'ZN_PI'
            Kp=0.9*A; Ti=3.33*Ltre; Td=0;
        case 'ZN_PID'
            Kp=1.2*A; Ti=2*Ltre; Td=0.5*Ltre;
        case 'Haalman_PI'
            Kp=(2/3)*A; Ti=T; Td=0;
        case 'CHR_PI'
            Kp=0.35*A; Ti=1.2*T; Td=0;
        case 'CHR_PID'
            Kp=0.6*A; Ti=T; Td=0.5*Ltre;
        case 'CC_PI'
            Kp=A*(0.9+rho/12);
            Ti=Ltre*(30+3*rho)/(9+20*rho); Td=0;
        case 'CC_PID'
            Kp=A*(4/3+rho/4);
            Ti=Ltre*(32+6*rho)/(13+8*rho);
            Td=4*Ltre/(11+2*rho);
        otherwise
            error('Ten bo dieu khien khong hop le: %s',Ten);
    end
end

function v = chonHienThi(coHienThi)
    if coHienThi, v='on'; else, v='off'; end
end

function luuHinh(h,thuMuc,tenFile,coHienThi)
    saveas(h,fullfile(thuMuc,tenFile));
    if ~coHienThi, close(h); end
end
